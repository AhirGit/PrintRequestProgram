//This program uses Singly Linked List to implement a Queue for printing request
//Queue follows FIFO method which is first come first serve basis
//The first request placed will be printed first
//The program remembers the print ID given by the user and creates a printing order accordingly
//Printing ID must be a unique integer value for specific requests
#include <iostream>
using namespace std;
#include "Queue.h"


//Main Function
int main()
{
 int choice, flag=1, value;
 cout<<"                              "<<endl;
 cout<<"******** WELCOME USER ********"<<endl;
 cout<<"                              "<<endl;
 cout<<"Please follow the instructions below:"<<endl;
 while( flag == 1)
 {
  cout<<"---------------------------------------------------"<<endl;
  cout<<"Press 1 for print request"<<endl;
  cout<<"Press 2 to complete printing next request"<<endl;
  cout<<"Press 3 to see the next request"<<endl;
  cout<<"Press 4 to see all the requests in order"<<endl;
  cout<<"Press 5 to turn off the process"<<endl;
  cout<<"---------------------------------------------------"<<endl;
  cin>>choice;
  switch (choice)
  {
  case 1: cout<<"Enter Unique Print ID: ";
          cin>>value;
          enqueue(value);
          cout<<"REQUEST PLACED!"<<endl;
          cout<<"---------------------------------------------------"<<endl;
          break;
  case 2: dequeue();
          cout<<"---------------------------------------------------"<<endl;
          cout<<"PRINTING COMPLETE!"<<endl;
          break;
  case 3: showfront();
          cout<<"---------------------------------------------------"<<endl;
          break;
  case 4: displayQueue();
          break;
  case 5: flag = 0;
          break;
  }
 }
 cout<<"---------------------------------------------------"<<endl;
 cout<<"Shutting down..."<<endl;
 cout<<"Process turned off"<<endl;
 cout<<"Thank You.See you next time!"<<endl;
 cout<<"---------------------------------------------------"<<endl;

 return 0;
}
