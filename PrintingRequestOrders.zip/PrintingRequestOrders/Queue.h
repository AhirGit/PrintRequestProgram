// Structure of Node.
struct Node
{
int data;

Node *link;
};

Node *front = NULL;
Node *rear = NULL;

//function to check if queue is empty or not
bool isempty()
{
 if(front == NULL && rear == NULL)
 return true;
 else
 return false;
}

//function to enter elements in queue
void enqueue ( int value )
{
 Node *ptr = new Node();
 ptr->data= value;
 ptr->link = NULL;

 //if inserting the first element/node
 if( front == NULL )
 {
  front = ptr;
  rear = ptr;
 }
 else
 {
  rear ->link = ptr;
  rear = ptr;
 }
}

//function to delete/remove element from queue
void dequeue ( )
{
 if( isempty() )
 cout<<"No request is being made\n";
 else
 //only one element/node in queue.
 if( front == rear)
 {
  delete front;
  front = rear = NULL;
 }
 else
 {
  Node *ptr = front;
  front = front->link;
  delete ptr;
 }
}

//function to show the element at front
void showfront( )
{
 if( isempty())
 cout<<"No request is being made\n";
 else
 cout<<"Next Request ID:"<<front->data<<endl;
}

//function to display queue
void displayQueue()
{
 if (isempty())
  cout<<"No request is being made\n";
 else
 {
  cout<<"---------------------------------------------------"<<endl;
  cout<<"Request Order (Unique Print ID): "<<endl;
  Node *ptr = front;
  while( ptr !=NULL)
  {
   cout<<ptr->data<<" "<<endl;
   ptr= ptr->link;
  }
  cout<<"---------------------------------------------------"<<endl;
 }
}
